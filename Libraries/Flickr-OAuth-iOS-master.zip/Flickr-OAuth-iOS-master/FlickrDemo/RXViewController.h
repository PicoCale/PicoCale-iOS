//
//  RXViewController.h
//  FlickrDemo
//
//  Created by Joseph Stein on 1/8/12.
//  Copyright (c) 2012 9mmedia. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RXFlickr.h"

@interface RXViewController : UIViewController <RXFlickrDelegate>

@end
