//
//  RXAppDelegate.h
//  FlickrDemo
//
//  Created by Joseph Stein on 1/8/12.
//  Copyright (c) 2012 9mmedia. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RXViewController;

@interface RXAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) RXViewController *viewController;

@end
