//
//  FlickrPhoto.m
//  Flickr Search
//
//  Created by Brandon Trebitowski on 6/28/12.
//  Copyright (c) 2012 Brandon Trebitowski. All rights reserved.
//

#import "FlickrPhoto.h"

@implementation FlickrPhoto

@end
