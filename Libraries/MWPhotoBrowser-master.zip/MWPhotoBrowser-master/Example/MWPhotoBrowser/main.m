//
//  main.m
//  MWPhotoBrowser
//
//  Created by Michael Waterfall on 07/04/2015.
//  Copyright (c) 2015 Michael Waterfall. All rights reserved.
//

@import UIKit;
#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
