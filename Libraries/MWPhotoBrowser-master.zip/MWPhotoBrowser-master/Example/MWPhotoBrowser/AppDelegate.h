//
//  AppDelegate.h
//  PhotoBrowserDemo
//
//  Created by Michael Waterfall on 31/12/2011.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

//@property (strong, nonatomic) UIViewController *viewController;

@end
