//
//  TestSuite.h
//  SynchronousRequestTest
//
//  Created by Lukhnos D. Liu on 6/12/09.
//  Copyright 2009 Lithoglyph Inc.. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>
#import "LFWebAPIKit.h"

@interface TestSuite : SenTestCase
{
	LFHTTPRequest *HTTPRequest;
}

@end
