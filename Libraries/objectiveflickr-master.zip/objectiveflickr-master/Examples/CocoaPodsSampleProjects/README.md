# ObjectiveFlickr Sample Projects Using CocoaPods

This directory contains sample projects that show you how to use [CocoaPods](http://cocoapods.org/) to install ObjectiveFlickr as a dependency.

For example, to build the PublicPhotos-iOS project, enter `PublicPhotos-iOS`, then run:

    pod install

Then open PublicPhotos.xcworkspace, add your API key and secret to `OFAPIKey.m`. Now you can build and run the sample app.
