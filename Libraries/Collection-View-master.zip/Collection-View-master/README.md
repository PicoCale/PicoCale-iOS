# Collection View

iOS Project demonstratring how to build a UICollectionView. 

Read more in my companion article here: http://pinkstone.co.uk/how-to-build-a-uicollectionview-in-ios-8/
